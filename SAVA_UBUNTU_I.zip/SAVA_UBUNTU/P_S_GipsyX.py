
def iwv(arqgipsyx,tm):
    lwetx,liwvx,count = [],[],0
    for j in arqgipsyx:
        e = j.split()
        if (e[4][len(e[4])-4:len(e[4])] == "WetZ"):
            wetzx = float(e[2])*1000 #"Delay WetZ "+" : "

            iwvx=round(((wetzx*1e8)/(461.5181*(22.10+(373900/tm))))/1000,3)

            lwetx.append(wetzx); liwvx.append(iwvx); count += 1
        if (count == 287):
            break
    tu = (lwetx,liwvx)
    return tu