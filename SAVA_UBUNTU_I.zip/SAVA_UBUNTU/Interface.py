# -*- coding: utf-8 -*-
import numpy as np

import GPT2                # Generates atmospheric parameters
import P_Bias              # Process Bias File
import CAB_INF             # Identify Relevant Information
import P_Ionosfera         # Process Ionosphere File
import P_Efemerides        # Process Ephemeris File
import Nome_Arquivos       # Generate the Name of Complementary Files
import Move_Arquivos       # Move files
import Data_Juliana_Modificada as DJ # Modified Julian Date
###############################################################################
import os                         # To Open Files and File Paths
import wx                         # Graphical Interface Library
import time                       # Count function execution time
import matplotlib                 # Plot of Static Graphics
matplotlib.use("wx")
matplotlib.use('WXAgg')
import pandas as pd
import shutil as shl              # Move SMOTH0_0.TDP file to folder File
from math import exp
import matplotlib.pyplot as plt
from pymap3d import ecef2geodetic as cg  # Convert Coord. Cart. in Geodesic
LP, it1, it2, it3, it4, TASK_RANGE, oprin, opebi, TA, WA, IA = [], 0, 0, 0, 0, 100, 1, 1, 0, 0, 0  # Processing Indicator TASK
###################################################################################
for j in range(0,24):
    for k in range(0,56,5):
        if (j < 10):
            j = "0"+str(j)
        if (k < 10):
            k = "0"+str(k)
        ve = str(j) + "H" + str(k)
        LP.append(ve)
###################################################################################
def men(self): # File Not Found Message!     ######################
    dlg = wx.MessageDialog(self, "File not found!"
          "\n Check that the Watch RINEX has been Loaded and Processed!"
          , "Atmospheric Water Vapor Estimation Software", wx.OK)
    dlg.ShowModal();dlg.Destroy()
def mene(self): # File Not Found Message!     ######################
    dlg = wx.MessageDialog(self, "Incompatible graph values!"
          "\n Check the graph parameters!"
          , "Atmospheric Water Vapor Estimation Software", wx.OK)
    dlg.ShowModal();dlg.Destroy()
def limporb(self):
    lporb = os.listdir(os.getcwd() + '/orb')
    for i in lporb:  # Remove zipped files
        if (i != "__pycache__"):
            try:
                os.remove(os.getcwd() + "/orb/" + i)
            except OSError as e:
                shl.rmtree(os.getcwd() + "/orb/" + i)
def limparq(self):
    lparq = os.listdir(os.getcwd() + '/Arquivos')
    for i in lparq:  # Remove files
        if (i != "__pycache__"):
            try:
                os.remove(os.getcwd() + "/Arquivos/" + i)
            except OSError as e:
                shl.rmtree(os.getcwd() + "/Arquivos/" + i)
########################################################################################
def PlotaG(self, ZP, ZT, yl, si, la, co): # Graphic plot
    fig, axs = plt.subplots()
    line1, = axs.plot(ZP, ZT, si, label=la, color=co)
    plt.rcParams['figure.figsize'] = (7.7, 5.2)
    plt.xlabel("Time [Hr:Min]")
    plt.ylabel(yl)
    plt.xticks(ZP, ZP, rotation=45)
    axs.legend()
    plt.show()
def check(self, par, to, tf, ZP1, ZP2): # Check plot interval
    if (int(to) > int(tf)):
        mene(self)
    else:
        la = par + data[0:10] + " - " + str(ZP1) + " to " + str(ZP2)
    return la
########################################################################################
def iwvf(self,arq, tm,ZHD,data):
    lztd, lzwd, liwv, lt, coe = [], [], [], [], 0
    lztd1, lzwd1, liwv1, lt1 = [], [], [], []
    def ndias(data): # Identifies the date and returns the day of the year
        s, count = pd.date_range("20000101", periods=16500), 0
        for k in s:
            count += 1
            if (str(k) == str(data)):
                break
        return count # Day of the year
    def eit(dj, count): # Receives the Julian date and the day of the year
        hora = int(((dj - ((count - 1) * 24 * 3600)) / 60) / 60) + 12
        min = ((dj - ((count - 1) * 24 * 3600)) / 60) - int(((dj - ((count - 1) * 24 * 3600)) / 60) / 60) * 60
        if (hora < 10):
            hora = '0'+str(hora)
        if (min < 10):
            min = '0'+str(min)
        epoca = str(hora) + 'H' + str(min) # + 'M'
        return epoca # Time of data epoch
    ####################################################################################
    arqsai = open(os.getcwd()+"/Series/"+str(data)[0:10]+"_SAVA.txt", 'w')
    for i in arq: # Process Gipsyx output file
        j = i.split()
        if ("WetZ" in i):
            nd, zwd = ndias(data), float(j[2]) * 1e3
            IWV = float(str((zwd * 1e5) / (461.5181 * (22.10 + (373900 / tm))))[0:11])  # Atmospheric Water Vapor
            ZTD, ds = float(zwd + ZHD), eit(int(j[0]), nd)
            lztd.append(ZTD); lzwd.append(zwd); liwv.append(IWV); lt.append(ds)
    for ee in LP: # Checks the existence of data at each time
        if (ee in lt[coe]):
            sai = str(lt[coe]) + " " + str(lztd[coe]) + " " + str(lzwd[coe]) + " " + str(liwv[coe])
            arqsai.write(sai);arqsai.write("\n");lztd1.append(lztd[coe])
            lzwd1.append(lzwd[coe]);liwv1.append(liwv[coe]);lt1.append(ee); coe += 1
        else:
            sai = str(ee) + " " + "0" + " " + "0"+ " " + "0"
            arqsai.write(sai);arqsai.write("\n");lztd1.append(0)
            lzwd1.append(0);liwv1.append(0);lt1.append(ee)
    return lt1,lztd1,lzwd1,liwv1
########################################################################################
def jpl(self, e, data, i,diretorio): # Get complementary files to run the GipsyX package
    if self.count == TASK_RANGE:
        self.timer.Stop()
    ano = data[0:4]
    os.system('curl https://sideshow.jpl.nasa.gov/pub/JPL_GPS_Products/Final/' + ano + '/' + data + i + '>' + data + i)
    if (i[len(i) - 3:len(i)] != ".py" and i[len(i) - 3:len(i)] != "vos" and i[len(i) - 3:len(i)] != "ies"
            and i[len(i) - 3:len(i)] != "cos" and i[len(i) - 3:len(i)] != "e__" and i[len(i) - 3:len(i)] != "orb"):
        shl.move(os.getcwd() + "/" + data + i, str(diretorio) + "/" + ano + '/' + data + i); nar = data + i
        self.OnNewItem(e, nar)
def bac(self, e, ele, lk, scount): # Informs which complementary file is being downloaded
    if self.count == TASK_RANGE:
        self.timer.Stop()
    self.statusbar.SetStatusText("  Downloading "+scount+" . . . ")
    os.system(lk)
    self.OnNewItem(e, ele)
########################################################################################
class MainWindow(wx.Frame):
    def __init__(self, parent, id=-1, dpi=None, *args, **kw):
        self.dirname = ''
        wx.Frame.__init__(self, parent, id=id, size=(1280, 720))
        self.SetBackgroundColour('DARK GREY')
        self.SetIcon(wx.Icon(os.getcwd()+'/Icos/'+'logo.ico', wx.BITMAP_TYPE_ICO))
        font = wx.Font(10, wx.DEFAULT, wx.NORMAL, wx.BOLD)
        #####   Software Header   #####################################################
        self.box4 = wx.StaticBox(self, -1, 'File Information', pos=(10, 15), size=(200, 110)).SetFont(font)
        self.TS01 = wx.StaticText(self, label='Name', pos=(20, 40))
        self.JS01 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(70, 35), size=(135, 25))
        self.TS02 = wx.StaticText(self, label='Date', pos=(20, 70))
        self.JS02 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(70, 65), size=(135, 25))
        self.TS03 = wx.StaticText(self, label='ID', pos=(20, 100))
        self.JS03 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(70, 95), size=(135, 25))
        self.TS01.SetFont(font);self.TS02.SetFont(font);self.TS03.SetFont(font)

        self.box5 = wx.StaticBox(self, -1, 'Complementary Files', pos=(225, 15), size=(240, 110)).SetFont(font)
        self.efeme = wx.StaticText(self, label="Ephemeris", pos=(235, 40))
        self.efe = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(325, 35), size=(135, 25))
        self.bias = wx.StaticText(self, label="Bias", pos=(235, 70))
        self.biass = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(325, 65), size=(135, 25))
        self.iono = wx.StaticText(self, label="Ionosphere", pos=(235, 100))
        self.ionos = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(325, 95), size=(135, 25))
        self.efeme.SetFont(font); self.bias.SetFont(font); self.iono.SetFont(font)

        self.box6 = wx.StaticBox(self, -1, 'Coord. [m]', pos=(480, 15), size=(150, 110)).SetFont(font)
        self.TS11 = wx.StaticText(self, label='X', pos=(490, 40))
        self.TS12 = wx.StaticText(self, label='Y', pos=(490, 70))
        self.TS13 = wx.StaticText(self, label='Z', pos=(490, 100))
        self.JS09 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(505, 35), size=(120, 25))
        self.JS10 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(505, 65), size=(120, 25))
        self.JS11 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(505, 95), size=(120, 25))
        self.TS11.SetFont(font);self.TS12.SetFont(font);self.TS13.SetFont(font)

        self.box7 = wx.StaticBox(self, -1, 'Coord. Geodesic', pos=(645, 15), size=(165, 110)).SetFont(font)
        self.TS07 = wx.StaticText(self, label='Lat', pos=(650, 38))
        self.TS17 = wx.StaticText(self, label='Lon', pos=(650, 68))
        self.TS09 = wx.StaticText(self, label='Alt', pos=(650, 98))
        self.JS06 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(680, 35), size=(125, 25))
        self.JS16 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(680, 65), size=(125, 25))
        self.JS08 = wx.TextCtrl(self, style=wx.TE_HT_ON_TEXT, pos=(680, 95), size=(125, 25))
        self.TS07.SetFont(font);self.TS17.SetFont(font);self.TS09.SetFont(font)
        ##########  User interaction buttons  #########################################
        self.rinex = wx.Button(parent=self, label="Open", size=(75, 44))
        self.rinex.SetFont(font)
        self.btn1 = wx.BitmapButton(self, bitmap=wx.Bitmap(os.getcwd()+'/Icos/'+'Nplay.png'))
        self.btn2 = wx.BitmapButton(self, bitmap=wx.Bitmap(os.getcwd()+'/Icos/'+'Nstop.png'))
        self.ZTD = wx.Button(self, label="ZTD", size=(75, 44))
        self.ZWD = wx.Button(self, label="ZWD", size=(75, 44))
        self.IWV = wx.Button(self, label="IWV", size=(75, 44))
        self.exit = wx.Button(self, 0, label="Exit", size=(75, 44))
        self.ZTD.SetFont(font);self.ZWD.SetFont(font);self.IWV.SetFont(font);self.exit.SetFont(font)
        ###############################################################################
        self.Bind(wx.EVT_BUTTON, self.OnZTD, self.ZTD)
        self.Bind(wx.EVT_BUTTON, self.OnZWD, self.ZWD)
        self.Bind(wx.EVT_BUTTON, self.OnIWV, self.IWV)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exit)
        self.Bind(wx.EVT_BUTTON, self.Onrinex, self.rinex)
        #####   Define Processing and Plot Buttons          ###########################
        self.count = 0
        self.timer = wx.Timer(self, 1)
        self.text = wx.StaticText(self)
        self.Bind(wx.EVT_BUTTON, self.OnStop, self.btn2)
        self.Bind(wx.EVT_TIMER, self.OnTimer, self.timer)
        self.Bind(wx.EVT_BUTTON, self.OnEXECUTE, self.btn1)

        panel = wx.Panel(self)
        self.listbox = wx.ListBox(panel, size=(308, wx.EXPAND)) # size=(308, 450)
        self.newBtn = wx.BitmapButton(self, -1, bitmap=wx.Bitmap(os.getcwd() + '/Icos/' + 'sava21.png'))
        self.Bind(wx.EVT_BUTTON, self.OnNewItem, self.newBtn)
        self.newBtn.SetFont(font)
        self.control = wx.TextCtrl(self, style=wx.TE_MULTILINE, size=(wx.EXPAND, wx.EXPAND))
        self.gauge = wx.Gauge(self, range=TASK_RANGE, size=(wx.EXPAND, 20))
        ########  UI design  ##########################################################
        self.sizer1 = wx.BoxSizer(wx.VERTICAL)
        self.sizer1.Add(self.newBtn, 0, wx.LEFT, border=5)
        self.sizer1.Add(panel, 0, wx.TOP|wx.LEFT, border=5)
        self.sizer4 = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer4.Add(self.rinex, 0, wx.LEFT )
        self.sizer4.Add(self.btn1, 0, wx.LEFT, border=2)
        self.sizer4.Add(self.btn2, 0, wx.LEFT, border=2)
        self.sizer4.Add(self.ZTD, 0, wx.LEFT, border=2)
        self.sizer4.Add(self.ZWD, 0, wx.LEFT, border=2)
        self.sizer4.Add(self.IWV, 0, wx.LEFT, border=2)
        self.sizer4.Add(self.exit, 0, wx.LEFT, border=2)

        self.box8 = wx.StaticBox(self, -1, 'Graph [00H00 : 23H55]', pos=(320, 200), size=(475, 154)).SetFont(font)
        self.TS04 = wx.StaticText(self, label='t0', pos=(764, 232)); self.TS04.SetFont(font)
        self.TS05 = wx.StaticText(self, label='tf', pos=(764, 302)); self.TS05.SetFont(font)
        self.inic = wx.Slider(self, -1, 0, 0, 276, wx.DefaultPosition, (415, 45), wx.SL_AUTOTICKS | wx.SL_HORIZONTAL | wx.SL_LABELS)
        self.fina = wx.Slider(self, -1, 288, 12, 288, wx.DefaultPosition, (415, 45), wx.SL_AUTOTICKS | wx.SL_HORIZONTAL | wx.SL_LABELS)
        self.inic.SetFont(font); self.fina.SetFont(font)

        self.sizer3 = wx.BoxSizer(wx.VERTICAL)
        self.sizer3.Add(self.sizer4, 0, wx.LEFT | wx.RIGHT, border=2)
        self.sizer3.Add(self.inic, 0, wx.LEFT | wx.TOP, border=24)
        self.sizer3.Add(self.fina, 0, wx.LEFT | wx.TOP | wx.BOTTOM, border=24)
        self.sizer3.Add(self.control, 0, wx.LEFT | wx.TOP | wx.RIGHT, border=5)

        self.sizer6 = wx.BoxSizer(wx.VERTICAL)
        self.sizer6.Add(self.gauge, 0, wx.LEFT, border=5)

        self.sizer5 = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer5.Add(self.sizer1, 0, wx.LEFT, border=2)
        self.sizer5.Add(self.sizer3, 0)

        # Use some sizers to see layout options
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.sizer6, 1, wx.TOP, border=(125))
        self.sizer.Add(self.sizer5, 2, wx.TOP|wx.BOTTOM, border=(5))
        self.sizer
        ###############################################################################
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("  Atmospheric Steam")
        # SETTING THE TOP MENU! #######################################################
        About = wx.Menu()
        filemenu = wx.Menu()
        Proresult = wx.Menu()
        menuOpen = filemenu.Append(wx.ID_OPEN, "&File", " Open a file to edit")
        menuExit = filemenu.Append(wx.ID_EXIT, "&Exit", " Terminate the program")
        menuAbout = About.Append(wx.ID_FILE1, "&About", "Information this program")
        menuRine = Proresult.Append(wx.ID_FILE2, "&RINEX", "Open RINEX of Observation!")
        menuEfem = Proresult.Append(wx.ID_FILE3, "&Ephemeris", "Open Ephemeris file!")
        menuBias = Proresult.Append(wx.ID_FILE4, "&Bias", "Open Bias file!")
        menuIono = Proresult.Append(wx.ID_FILE5, "&Ionosphere", "Open Ionosphere file!")
        menuFina = Proresult.Append(wx.ID_FILE6, "Out_SAVA.txt", "Open SAVA output file")
        # CREATING THE MENU! ###########################################################
        menuBar = wx.MenuBar()
        menuBar.Append(filemenu, "&Menu")      # Adding the "filemenu" to the MenuBar
        menuBar.Append(Proresult, "&Navegar")  # Adding the "filemenu" to the MenuBar
        menuBar.Append(About, "&Help")         # Adding the "filemenu" to the MenuBar
        self.SetMenuBar(menuBar)               # Adding the MenuBar to the Frame content.
        # Events! #####################################################################
        self.Bind(wx.EVT_MENU, self.OnOpen, menuOpen)
        self.Bind(wx.EVT_MENU, self.OnExit, menuExit)
        self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)
        self.Bind(wx.EVT_MENU, self.OnRine, menuRine)
        self.Bind(wx.EVT_MENU, self.OnEfem, menuEfem)
        self.Bind(wx.EVT_MENU, self.OnBias, menuBias)
        self.Bind(wx.EVT_MENU, self.OnIono, menuIono)
        self.Bind(wx.EVT_MENU, self.OnFina, menuFina)
        ###############################################################################
        self.SetSizer(self.sizer)
        self.SetAutoLayout(2)
        self.sizer.Fit(self)
        self.Show()
        self.Centre()
    ###################################################################################
    def OnNewItem(self, e, text): # Panel list on the left of UI design
        if text != '':
            self.listbox.Append(text)
    def OnAbout(self, e):  # Create a message dialog box
        dlg = wx.MessageDialog(self, "Description of Plot Buttons!"
                                      "\n ZTD : Total Zenith Delay!"
                                      "\n ZWD : Zenith Wet Delay!"
                                      "\n IWV : Integrated Atmosphere Vapor!"
                                      "\n Alt : Station Altitude in [meters]!"
                                      "\n Software Developed in wxPython!"
                                , "Atmospheric Water Vapor Software", wx.OK)
        dlg.ShowModal(); dlg.Destroy()
    def OnExit(self, e): # Clean file folders and close interface
        limporb(self)
        limparq(self)
        self.Close(True)  # Close the frame.
    def OnOpen(self, e): # Allows the user to choose and view a file in the right frame of the interface
        dlg = wx.FileDialog(self, "Choose a file", self.dirname, "", "*.*", wx.FD_OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            self.filename = dlg.GetFilename(); self.dirname = dlg.GetDirectory()
            op = open(os.path.join(self.dirname, self.filename), 'r')
            self.control.SetValue(op.read()); op.close()
        dlg.Destroy()
    def Onrinex(self, e): # Load RINEX and Fill Header Information! ###########
        dlg = wx.FileDialog(self, "Choose a file", self.dirname, "", "*.*", wx.FD_OPEN)
        global rel; rel = time.time()
        limpa = open(os.getcwd()+'/Icos/limpo.txt','r'); self.control.SetValue(limpa.read())
        if dlg.ShowModal() == wx.ID_OK:
            self.filename = dlg.GetFilename();self.dirname = dlg.GetDirectory()
            ar = open(os.path.join(self.dirname, self.filename), 'r')
            global arq, oprin; arq, oprin = os.path.join(self.dirname, self.filename), 2
            limporb(self)
            limparq(self)
            global nome_arq; nome_arq = self.filename  # (xu,yu,zu,data,diano,esta,arqobs,L1,C1)
            global data; x,y,z,data,diano,ID = CAB_INF.rinex(ar)     # Coord Cartesian axis X,Y,Z
            self.JS01.SetValue(nome_arq); self.JS02.SetValue(data[0:11]); self.JS03.SetValue(ID)
            self.JS09.SetValue(x);self.JS10.SetValue(y);self.JS11.SetValue(z)
            ###############################################################################
            global it1,it2,lk1,it3,it4,lk3,lk4,diaan,lat,lo,al # Names and links of downloads (files)
            it1,it2,lk1,it3,it4,lk3,lk4,diaan = Nome_Arquivos.nome_arq(data, diano)
            lat,lo,al = cg(float(x),float(y),float(z)); self.efe.SetValue(it1)
            self.JS08.SetValue(str(al)); self.JS06.SetValue(str(lat)); self.JS16.SetValue(str(lo))
            self.biass.SetValue(it3); self.ionos.SetValue(it4); ar.close(); dlg.Destroy()
    ###################################################################################
    def OnEXECUTE(self, e): # Starts processing the loaded RINEX
        if self.count >= TASK_RANGE:
            return
        ano = data[0:4]
        if os.path.isdir("orb/" + ano):
            pass
        else:
            os.mkdir(os.getcwd() + "/orb/" + ano)
        self.listbox.Clear()
        self.timer.Start(100)
        self.statusbar.SetStatusText("  Processing! "+str(round(time.time()-rel,2)))
    def OnStop(self, e): # Stops RINEX processing
        if self.count == 0 or self.count >= TASK_RANGE or not self.timer.IsRunning():
            return
        self.timer.Stop()
        self.statusbar.SetStatusText("  Processing Stopped!"+str(self.time.IsRunning))
    def OnTimer(self, e): #
        self.count = self.count + 1
        self.gauge.SetValue(self.count)
        orbita = os.path.join(os.getcwd() + "/orb")
        if (self.count == 4): # Download complementary ephemeris file
            bac(self, e, it1, lk1, 'Ephemeris')
        if (self.count == 8): # Download complementary bias file
            bac(self, e, it3, lk3, 'Bias DCB')
        if (self.count == 12): # Download ionospheric add-on file
            bac(self, e, it4, lk4, 'Ionosphere')
        if (self.count == 14): # Unzip and process supplementary files
            cam = os.getcwd() + "/Arquivos/"; global d_ef, d_bi, d_io, it2;
            v = "7z e " + os.getcwd() + "/"; os.system(v + it1); os.system(v + it3); os.system(v + it4)
            lista = Move_Arquivos.move_arq(os.listdir(os.getcwd()))  # Move arquivos DESCOMPACTADOS
            for itn in lista:
                if (itn == it2[0:len(itn)].upper() or itn == it2[0:len(itn)].lower()):
                    it2 = itn
            arq_efem, arq_bias, arq_iono = cam + it2, cam + it3[0:len(it3) - 2], cam + it4[0:len(it4) - 2]
            self.statusbar.SetStatusText("  Processing Supplementary Files . . .")
            d_ef = P_Efemerides.Proc_efe(arq_efem)  # Ephemeris Data
            d_bi = P_Bias.Proc_bias(arq_bias)       # BIAS data
            d_io = P_Ionosfera.Proc_iono(arq_iono)  # Ionosphere Data
        ld = ['.ant.gz', '.eo.gz', '.frame.gz', '.pos.gz', '.shad.gz', '.tdp.gz', '.wlpb.gz', '.x.gz',
              '_hr.tdp.gz', '_nf.eo.gz', '_nf.pos.gz', '_nf.tdp.gz', '_nf.wlpb.gz', '_nf_hr.tdp.gz',
              '_nnr.eo.gz', '_nnr.pos.gz', '_nnr.tdp.gz', '_nnr.wlpb.gz', '_nnr.x.gz', '_nnr_hr.tdp.gz']
        self.statusbar.SetStatusText("  Downloading GipsyX Supplemental Files . . . ")
        if (self.count == 16): # Downloading GipsyX Supplemental Files
            jpl(self, e, data[0:10],ld[0],orbita)
        if (self.count == 20):
            jpl(self, e, data[0:10], ld[1], orbita)
        if (self.count == 24):
            jpl(self, e, data[0:10], ld[2], orbita)
        if (self.count == 28):
            jpl(self, e, data[0:10], ld[3], orbita)
        if (self.count == 32):
            jpl(self, e, data[0:10], ld[4], orbita)
        if (self.count == 36):
            jpl(self, e, data[0:10], ld[5], orbita)
        if (self.count == 40):
            jpl(self, e, data[0:10], ld[6], orbita)
        if (self.count == 44):
            jpl(self, e, data[0:10], ld[7], orbita)
        if (self.count == 48):
            jpl(self, e, data[0:10], ld[8], orbita)
        if (self.count == 52):
            jpl(self, e, data[0:10], ld[9], orbita)
        if (self.count == 56):
            jpl(self, e, data[0:10], ld[10], orbita)
        if (self.count == 60):
            jpl(self, e, data[0:10], ld[11], orbita)
        if (self.count == 64):
            jpl(self, e, data[0:10], ld[12], orbita)
        if (self.count == 68):
            jpl(self, e, data[0:10], ld[13], orbita)
        if (self.count == 72):
            jpl(self, e, data[0:10], ld[14], orbita)
        if (self.count == 76):
            jpl(self, e, data[0:10], ld[15], orbita)
        if (self.count == 80):
            jpl(self, e, data[0:10], ld[16], orbita)
        if (self.count == 84):
            jpl(self, e, data[0:10], ld[17], orbita)
        if (self.count == 88):
            jpl(self, e, data[0:10], ld[18], orbita)
        if (self.count == 92):
            jpl(self, e, data[0:10], ld[19], orbita)
        ###################################################################################
        if self.count == TASK_RANGE:
            self.timer.Stop()
            arqt = open('gipsyx.sh','w') # Create GipsyX Processing Tree File
            arqt.write('#!/bin/bash')
            arqt.write('\n')
            arqt.write('source /home/vapo/GipsyX-rc0.2/rc_GipsyX.sh')
            arqt.write('\n')
            arqt.write('rinex2StaDb.py '+arq+' -outFile RidgecrestDb') # You only need the name of the RINEX Observation file
            arqt.write('\n')
            arqt.write('gd2e.py -rnxFile '+arq+' -runType PPP -staDb RidgecrestDb -GNSSproducts '+orbita+' -prodTypeGNSS nf -HighRateProducts -gdCov')
            arqt.close()
            self.statusbar.SetStatusText("  Running GipsyX . . . ")
            os.system('./gipsyx.sh') # Run GipsyX processing tree
            lista = Move_Arquivos.move_arq(os.listdir(os.getcwd()))  # Move unzipped files
            dmjd = float(DJ.dj(data))
            ev, p, T, ah, aw, undu, dlat, dlon, la, dT = GPT2.gpt2(lat, lo, al, dmjd)
            # Partial Vapor Pressure, Atmospheric Pressure, Temperature, Dry, Wet,
            # Geoid Altitude, dlat, dlon, Vapor Reduction Factor, Temperature Lapse respectively
            es, tm = 6.108 * 10 ** ((7.5 * T) / (237.3 + T)), round(273.2972 + 0.01063 * (273.15 + T), 2)  # In (mbar ou hPa), Kelvin
            ###############################################################################
            arqsm = open(os.getcwd()+"/Arquivos/smooth0_0.tdp") # Process GipsyX output file
            ZHD = ((p) * 2.27 * exp(-(undu) * 0.000116))  # Hydrostatic delay
            global ZP, ZT, ZW, IW; ZP, ZT, ZW, IW = iwvf(self, arqsm, tm, ZHD, data)
            global opebi; opebi = 2
            self.statusbar.SetStatusText("  Processing Completed 100%! "+str(round(time.time()-rel, 2))+'seg')
            self.count = 0
    ###################################################################################
    def OnRine(self, e):    # View the loaded RINEX file
        if (oprin > 1):
            Rine = open(arq, 'r')
            self.control.SetValue(Rine.read()); Rine.close()
        else:
            mens = men(self)
    def OnEfem(self, e):    # View the ephemeris file
        if (opebi > 1):
            efe = open(os.getcwd() + "/Arquivos/" + it2, 'r')
            self.control.SetValue(efe.read()); efe.close()
        else:
            mens = men(self)
    def OnBias(self, e):    # View the bias file
        if (opebi > 1):
            vie = open(os.getcwd() + "/Arquivos/" + it3[0:len(it3) - 2], 'r')
            self.control.SetValue(vie.read()); vie.close()
        else:
            mens = men(self)
    def OnIono(self, e):    # View the ionospheric file
        if (opebi > 1):
            ion = open(os.getcwd() + "/Arquivos/" + it4[0:len(it4) - 2], 'r')
            self.control.SetValue(ion.read()); ion.close()
        else:
            mens = men(self)
    def OnFina(self, e):    # Open the Output File_SAVA.txt
        if (opebi > 1):
            Final = open(os.getcwd()+"/Series/"+str(data)[0:10]+"_SAVA.txt", 'r')
            self.control.SetValue(Final.read());Final.close()
        else:
            mens = men(self)
    #####################################################   Plot Buttons    #####
    def OnZTD(self, e): # Total zenith delay plot
        if (opebi > 1):
            to, tf = int(self.inic.GetValue()), int(self.fina.GetValue())
            PlotaG(self, ZP[to:tf], ZT[to:tf], "Delay [mm]",'s--',
                   check(self, 'ZTD ', to, tf, str(ZP[to]), str(ZP[tf - 1])), 'blue')
        else:
            mens = men(self)
    def OnZWD(self, e): # Zenith wet delay plot
        if (opebi > 1):
            to, tf = int(self.inic.GetValue()), int(self.fina.GetValue())
            PlotaG(self, ZP[to:tf], ZW[to:tf], "Delay [mm]", 'o--',
                   check(self, 'ZWD ', to, tf, str(ZP[to]), str(ZP[tf - 1])), 'red', )
        else:
            mens = men(self)
    def OnIWV(self, e): # Plots the integrated steam from the atmosphere
        if (opebi > 1):
            to, tf = int(self.inic.GetValue()), int(self.fina.GetValue())
            PlotaG(self, ZP[to:tf], IW[to:tf], "IWV [kg/m^2]", '*--',
                   check(self, 'IWV ', to, tf, str(ZP[to]), str(ZP[tf - 1])), 'green', )
        else:
            mens = men(self)

def main():
    app = wx.App(redirect=False)
    ex = MainWindow(None, title='Centering')
    ex.Show()
    app.MainLoop()

if __name__ == '__main__':
    main()

"""
information panel
action buttons
Graph Adjustment Bars
File preview pane
list of complementary files
status bar
'Graph [t0=00H00, tf=23H55]'
"""
