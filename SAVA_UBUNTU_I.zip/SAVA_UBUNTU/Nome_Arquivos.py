# -*- coding: utf-8 -*-
import pandas as pd
def nome_arq(data,diano): # Identifies the year of RINEX and generates the names and links to the complementary files
    s = pd.date_range("19800101", periods=16500); dicdata = {}; count = 0
    for k in s:
        dicdata.update({str(k): str(count)}); count +=1
    if (len(data) < 19):
        if (int(data[8:10]) < 10):
            data = data[0:8]+data[8:]

    diadoano = 1+int(dicdata[data])-int(dicdata[diano])
    if (diadoano <100):
        diaano = "0"+str(diadoano)+"0"
    else:
        diaano = str(diadoano)+"0"

    diadaseamana = 2; ndesemanas = -1
    for ki in range(0,int(dicdata[data])):
        if (diadaseamana == 6):
            ndesemanas +=1; diadaseamana = -1
        diadaseamana +=1
    # To Obtain Ephemeris File Name
    if (int(data[0:4]) < 2012):
        iten1 = "nga"+str(ndesemanas)+".exe"
    elif ( int(data[0:4]) >= 2019):
        iten1 = "nga"+str(ndesemanas)+str(diadaseamana)+".eph"
    else:
        iten1 = "nga"+str(ndesemanas)+str(diadaseamana)+".Z"

    # Standardized Names and Email Addresses
    iten2 = "NGA"+str(ndesemanas)+str(diadaseamana)+".EPH" # Uncompressed Ephemeris
    link1 = "curl ftp://ftp.nga.mil/pub2/gps/pedata/"+data[0:4]+"pe/"+iten1+">"+iten1
    iten3 = "CODG"+str(diaano)+"."+data[2:4]+"I.Z"         # Bias
    iten4 = "CGIM"+str(diaano)+"."+data[2:4]+"N.Z"         # Ionosphere
    link3 = "curl http://ftp.aiub.unibe.ch/CODE/"+data[0:4]+"/"+iten3+">"+iten3
    link4 = "curl http://ftp.aiub.unibe.ch/CODE/"+data[0:4]+"/"+iten4+">"+iten4
    tupla1 = (iten1,iten2,link1,iten3,iten4,link3,link4,diaano[0:3])
    return tupla1
