# -*- coding: utf-8 -*-

def Proc_bias(arq_bias):
    dicbias = {} # Satellite Bias List and Dictionary
    arqbia = open(arq_bias, 'r')
    for k in arqbia: # Satellite Bias in (mm)
        kk = k.split()
        for kkk in kk:
            if (kkk == "PRN"):
                if (kk[0][0] == "G"):
                    biasat = round(float(kk[1])*0.299792458,3)
                    dicbias.update({kk[0][1:3]: str(biasat) })

    return dicbias
