# -*- coding: utf-8 -*-
def Proc_iono(arq_iono):
    arqion = open(arq_iono, 'r')
    global Ion
    for i in arqion:
        ii = i.split()
        for iii in ii:
            if (iii == "ALPHA"):
                s1 = float(str(i[3:10]+"E"+(i[11:14])))
                s2 = float(str(i[15:22]+"E"+(i[23:26])))
                s3 = float(str(i[27:34]+"E"+(i[35:38])))
                s4 = float(str(i[39:46]+"E"+(i[47:52])))
                Ion = round((s1+s2+s3+s4)*299792458,2)  #Iona = round(0.000000100*299792458,2)
    return Ion
