# -*- coding: utf-8 -*-
import os
from math import cos,sin,floor,ceil,exp,radians,copysign

def gpt2(lat,lon,alt,dmjd):
    arq = open(os.getcwd()+"/Icos"+"/gpt2_1w.grd.txt",'r')
    dlat = radians(lat); dlon = radians(lon) # Latitude and Longitude in Degrees; for Radians
    hell = alt; pi = 3.14159265359e0; IF1 = 0; EL2 = 0; nl = 0
    dmjd1 = dmjd-51544.5      # Reference season 1 January 2000
    dMtr = 28.965e-3          # Molar Mass of Dry Air in kg/mol
    gm = 9.80665e0            # Average Gravity in m/s**2
    Rg = 8.3143e0             # Universal Gas Constant in J/K/mol
    it = 1  # case 1: No Static Time Variations - case 0: With Variations (Year and Semester)
    if (it==1): # Factors for Constant Parameter Ranges
        cosfy = 0; coshy = 0; sinfy = 0; sinhy = 0
    else:
        cosfy = cos(dmjd1/365.25*2*pi); coshy = cos(dmjd1/365.25*4*pi)
        sinfy = sin(dmjd1/365.25*2*pi); sinhy = sin(dmjd1/365.25*4*pi)
    ###############################################################################
    if ((dlon) < 0):          # Only Positive Longitude in Degrees
        plon = ((dlon) + 2*pi)*180/pi
    else:
        plon = (dlon)*180/pi
    ppod = (-dlat + pi/2)*180/pi                        # Transform to Polar Distance in Degrees
    ipod = floor((ppod))+1 ; ilon = floor((plon+1))+1   # Informs the line closest to the grid
    diffpod = (lat - (ipod - 0.5)); difflon = (lon - (ilon - 0.5)) # Positive or negative normalized differences
    if (ipod == 181): # Added by HCY Changed to 1 grade (GP) grid
        ipod = 180
    if (ilon == 361): # Added by GP
        ilon = 1
    if (ilon == 0):
        ilon = 360
    indx = (ipod - 1)*360 + ilon # Gets the line number corresponding to the 1-degree grid index (GAP)
    bilinear = 0                 # Near poles: nearest neighbor interpolation, otherwise: bilinear
    if (0.5 < ppod < 179.5):
           bilinear = 1
    ################################################################################
    for i in arq:
        ii = i.split(); nl +=1
        if (nl == indx):
            if (bilinear == 1):
                P0 = float(ii[2]) + float(ii[3])*cosfy + float(ii[4])*sinfy + float(ii[5])*coshy + float(ii[6])*sinhy
                T0 = float(ii[7]) + float(ii[8])*cosfy + float(ii[9])*sinfy + float(ii[10])*coshy + float(ii[11])*sinhy
                Q0 = (float(ii[12])+float(ii[13])*cosfy+float(ii[14])*sinfy+float(ii[15])*coshy+float(ii[16])*sinhy)/1000
                DT = (float(ii[17])+float(ii[18])*cosfy+float(ii[19])*sinfy+float(ii[20])*coshy+float(ii[21])*sinhy)/1000
                # Transforming Ellipsoidal Height into Orthometric
                undu = float(ii[22])      # Geoid Ripple in (m)
                hgt = hell-undu
                Hs = float(ii[23])        # Grid Orthometric Altitude in (m)
                redh = hgt - Hs           # Height of (Station - grid)
                T = T0 + DT*redh - 273.15 # Temperature at the height of the season in Celsius
                dT = DT*1000e0            # Temperature lapse rate in degrees / km
                Tv = T0*(1+0.6077*Q0)     # Virtual temperature in Kelvin
                c = gm*dMtr/(Rg*Tv)
                p = (P0*exp(-c*redh))/100 # Pressure in hPa
                # Hydrostatic Coefficient (ah)
                ah =(float(ii[24])+float(ii[25])*cosfy+float(ii[26])*sinfy+float(ii[27])*coshy+float(ii[28])*sinhy)/1000
                # Wet Coefficient (aw)
                aw =(float(ii[29])+float(ii[30])*cosfy+float(ii[31])*sinfy+float(ii[32])*coshy+float(ii[33])*sinhy)/1000
                # Water vapor reduction factor there - added by GP
                la = float(ii[34]) + float(ii[35])*cosfy + float(ii[36])*sinfy + float(ii[37])*coshy + float(ii[38])*sinhy
                # Average temperature of water vapor Tm - added by GP
                Tm = float(ii[39]) + float(ii[40])*cosfy + float(ii[41])*sinfy + float(ii[42])*coshy + float(ii[43])*sinhy
                # Water vapor pressure in hPa - changed by GP
                e0 = Q0*P0/(0.622+0.378*Q0)/100 # On the grid
                ef = e0*(100*p/P0)**(la+1) # At station height - (14) Askne and Nordius, 1987
                IF1 = 1

            else: # Bilinear interpolation
                ipod1 = ipod + copysign(diffpod);
                ilon1 = ilon + copysign(difflon);
                if (ilon1 == 361): # Changed to 1 grade grid (GP)
                    ilon1 = 1
                if (ilon1 == 0):
                    ilon1 = 360
                indx2 = (ipod1 - 1)*360 + ilon  # Ao longo da mesma longitude
                indx3 = (ipod - 1)*360 + ilon1  # Ao longo da mesma distância polar
                indx4 = (ipod1 - 1)*360 + ilon1 # Diagonal
                for j in range(1,5):
                    if (nl == indx[j]):
                        # Transforming ellipsoidal height into orthometric height: Hortho = -N + Inferno
                        P0 = float(ii[2]) + float(ii[3])*cosfy + float(ii[4])*sinfy + float(ii[5])*coshy + float(ii[6])*sinhy
                        T0 = float(ii[7]) + float(ii[8])*cosfy + float(ii[9])*sinfy + float(ii[10])*coshy + float(ii[11])*sinhy
                        Q0j =(float(ii[12])+float(ii[13])*cosfy+float(ii[14])*sinfy+float(ii[15])*coshy+float(ii[16])*sinhy)/1000
                        DTj =(float(ii[17])+float(ii[18])*cosfy+float(ii[19])*sinfy+float(ii[20])*coshy+float(ii[21])*sinhy)/1000
                        unduj = float(ii[22]) # Geoid Ripple in (m)
                        Hsj = float(ii[23])   # Orthometric Altitude in (m)
                        hgt = hell-unduj      # Transforming Ellipsoidal Height into Orthometric
                        redh = hgt - Hsj      # Height of (Station - grid)
                        Tj = T0 + DTj*redh - 273.15 # Temperature at the height of the season in Celsius
                        dTj = DTj*1000e0            # Temperature lapse rate in degrees / km
                        Tv = T0*(1+0.6077*Q0j)      # Virtual temperature in Kelvin
                        c = gm*dMtr/(Rg*Tv)
                        pj = (P0*exp(-c*redh))/100  # Pressure in hPa
                        # Hydrostatic Coefficient (ah)
                        ahj =(float(ii[24])+float(ii[25])*cosfy+float(ii[26])*sinfy+float(ii[27])*coshy+float(ii[28])*sinhy)/1000
                        # Wet Coefficient (aw)
                        awj =(float(ii[29])+float(ii[30])*cosfy+float(ii[31])*sinfy+float(ii[32])*coshy+float(ii[33])*sinhy)/1000
                        # Water vapor reduction factor there - added by GP
                        laj = float(ii[34]) + float(ii[35])*cosfy + float(ii[36])*sinfy + float(ii[37])*coshy + float(ii[38])*sinhy
                        # Average temperature of water vapor Tm - added by GP
                        Tmj = float(ii[39]) + float(ii[40])*cosfy + float(ii[41])*sinfy + float(ii[42])*coshy + float(ii[43])*sinhy
                        # Water vapor pressure in hPa - changed by GP
                        e0 = Q0j*P0/(0.622+0.378*Q0j)/100 # On the grid
                        ej = e0*(100*pj/P0)**(laj+1); # At station height - (14) Askne and Nordius, 1987
                dnpod1 = abs(diffpod) # Distance closer to the point
                dnpod2 = 1 - dnpod1   # Distance to distant point
                dnlon1 = abs(difflon); dnlon2 = 1 - dnlon1

                # Pressure
                R1 = dnpod2*pj(1)+dnpod1*pj(2); R2 = dnpod2*pj(3)+dnpod1*pj(4);
                pjf = dnlon2*R1+dnlon1*R2;
                # Temperature
                R1 = dnpod2*Tj(1)+dnpod1*Tj(2); R2 = dnpod2*Tj(3)+dnpod1*Tj(4);
                Tjf = dnlon2*R1+dnlon1*R2;
                # Temperature in Degrees per km
                R1 = dnpod2*dTj(1)+dnpod1*dTj(2); R2 = dnpod2*dTj(3)+dnpod1*dTj(4);
                dTjf = (dnlon2*R1+dnlon1*R2)*1000;
                # Water vapor pressure in hPa - changed by GP
                R1 = dnpod2*ej(1)+dnpod1*ej(2); R2 = dnpod2*ej(3)+dnpod1*ej(4);
                ejf = dnlon2*R1+dnlon1*R2;
                # Hydrostatic Coefficient
                R1 = dnpod2*ahj(1)+dnpod1*ahj(2); R2 = dnpod2*ahj(3)+dnpod1*ahj(4);
                ahjf = dnlon2*R1+dnlon1*R2;
                # Wet Coefficient
                R1 = dnpod2*awj(1)+dnpod1*awj(2); R2 = dnpod2*awj(3)+dnpod1*awj(4);
                awjf = dnlon2*R1+dnlon1*R2;
                # Ripple
                R1 = dnpod2*unduj(1)+dnpod1*unduj(2); R2 = dnpod2*unduj(3)+dnpod1*unduj(4);
                undujf = dnlon2*R1+dnlon1*R2;
                # Water vapor reduction factor there - added by GP
                R1 = dnpod2*laj(1)+dnpod1*laj(2); R2 = dnpod2*laj(3)+dnpod1*laj(4);
                lajf = dnlon2*R1+dnlon1*R2;
                # Average temperature of water vapor Tm - added by GP
                R1 = dnpod2*Tmj(1)+dnpod1*Tmj(2); R2 = dnpod2*Tmj(3)+dnpod1*Tmj(4);
                Tmjf = dnlon2*R1+dnlon1*R2;
                EL2 = 1
    if (IF1 == 1):
        sif = (ef,p,T,ah,aw,undu,dlat,dlon,la,dT)
        return sif
    if (EL2 == 1):
        sel = (ejf,pjf,Tjf,ahjf,awjf,undujf,dlat,dlon,lajf,dTj)
        return sel
