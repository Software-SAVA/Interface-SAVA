# -*- coding: utf-8 -*-
def Proc_efe(arq_efem):
    arqefe = open(arq_efem); les =0;lns =0;LEE =[];LVP =[] # Epochs of Ephemeris and Satellite Coordinates
    for sc in arqefe:
        cs = sc.split()
        for scc in cs:
            if (scc == "48"): # 30 min intervals between seasons
                inter = int(1)
            if (scc == "96"):  # 15 min intervals between seasons
                inter = int(2)
            if (scc == "288"): # 05 min intervals between seasons
                inter = int(3)
        if (cs[0] == "*"):
            hora = sc[14:16]; min = sc[17:19]; seg = sc[22:24]
            if (sc[14] == " "):
                hora = "0" + sc[15]
            if (sc[17] == " "):
                min = "0" + sc[18]
            if (sc[21] == " "):
                seg = "0" + sc[23]
            if (sc[22] == "."):
                seg = "0" + sc[23]
            epoca = hora + " " + min + " " + seg
            LEE.append(epoca); dig = int(sc[8:10]); les += 1
        if (cs[0] == "P"):  ##### Satellite Coordinates (xs,ys,zs) #####
            if (float(cs[1]) < 10):
                cs[1] = "0" + cs[1]
            vpos = cs[1]+" : "+str(cs[2])+" : "+str(cs[3])+" : "+str(cs[4])+" : "+str(cs[5])
            LVP.append(vpos); lns+=1
    #####################################################################################
    nse = int(lns/les); dictefe = {}; LEF = []; ns = 0
    for i in LEE:
        for j in range(ns,ns+nse):
            if (j+1 == len(LVP)):
                break
            ej = LVP[j]; LEF.append(ej); ns +=1
        dictefe.update({i: LEF}); LEF = []
    tupla3 = (dictefe,inter,dig)
    return tupla3
