# -*- coding: utf-8 -*-

def rinex(arquivo):
    for sa in arquivo:
        termos = sa.split()
        for sb in range(0, len(termos)):
            if (termos[sb] == "XYZ"):
                if (termos[2] != "0.0000"):
                    # Coord Cartesianas da Antena (m)
                    global xu,yu,zu; xu,yu,zu = termos[0],termos[1],termos[2]
            if (termos[sb] == "NAME"):
                global esta; esta = termos[0]
            if (termos[sb] == "TIME"):
                global data,diano
                if (int(termos[1]) <= 9):
                    mess = "0"+str(int(termos[1]))
                if (int(termos[2]) <= 9):
                    dia = "0"+str(int(termos[2]))
                else:
                    dia = str(int(termos[2]))
                data = termos[0]+"-"+mess+"-"+dia+" 00:00:00"
                diano = termos[0]+"-"+"01"+"-"+"01"+" 00:00:00"
    tupla = (xu,yu,zu,data,diano,esta)
    return tupla
