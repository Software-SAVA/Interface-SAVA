#!/bin/bash
source /home/vapo/GipsyX-rc0.2/rc_GipsyX.sh
rinex2StaDb.py /home/vapo/Documents/GPSL06010020110404000000.11o -outFile RidgecrestDb
gd2e.py -rnxFile /home/vapo/Documents/GPSL06010020110404000000.11o -runType PPP -staDb RidgecrestDb -GNSSproducts /home/vapo/PycharmProjects/vapo/SAVA_UBUNTU/orb -prodTypeGNSS nf -HighRateProducts -gdCov