# -*- coding: utf-8 -*-
import os
import shutil as sh

lista_arq = []
def move_arq(lista):
    for i in lista:
        nc = len(i)
        if (i[nc-3:nc] != ".py" and i[nc-3:nc] != "vos" and i[nc-3:nc] != "ies" and i[nc-3:nc] != ".sh"
            and i[nc-3:nc] != "cos" and i[nc-3:nc] != "e__" and i[nc-3:nc] != "orb"):
            lista_arq.append(i)
            end_orig = os.getcwd()+"/"+i # Caminho Original dos Arquivos
            end_fina = os.getcwd()+"/Arquivos/"+i
            sh.move(end_orig,end_fina) # Move o arquivo para pasta de Arquivos
    return lista_arq
