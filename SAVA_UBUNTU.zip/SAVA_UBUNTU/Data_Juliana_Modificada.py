# -*- coding: utf-8 -*-
import datetime
import math

def get_julian_datetime(date): # Ensure correct format
    if not isinstance(date, datetime.datetime):
        raise TypeError('Invalid type for parameter "date" - expecting datetime')
    elif date.year < 1801 or date.year > 2099:
        raise ValueError('Datetime must be between year 1801 and 2099')
    # Perform the calculation
    julian_datetime = 367 * date.year - int((7 * (date.year + int((date.month + 9) / 12.0))) / 4.0) + \
                      int((275 * date.month) / 9.0) + date.day + 1721013.5 + \
                      (date.hour + date.minute / 60.0 + date.second / math.pow(60,2)) / 24.0 -\
                      0.5 * math.copysign(1, 100 * date.year + date.month - 190002.5) + 0.5
    return julian_datetime

def dj(data):
    data_utc = data
    yy = int(data_utc[0:4])             # Ano # int("20"+data_utc[0:4])        # Ano
    me = int(data_utc[5:7])             # Mês
    di = int(data_utc[8:10])            # Dia
    hr = int(data_utc[11:13])           # Hora
    mi = int(data_utc[14:16])           # Minuto
    sg = int(data_utc[17:19].strip())   # Segundo print("DATA Final Para JD: ",yy,me,di,hr,mi,sg)
    data = datetime.datetime(yy, me, di, hr, mi,sg)  # DIA JULIANO
    JDD = get_julian_datetime(data)
    MJD = JDD-2400000.5                         # DIA JULIANO MODIFICADO
    dmjd = str(MJD)[0:(str(MJD).find(".")+6)]   # DIA JULIANO MODIFICADO FINAL #print("Data Juliana",JDD)
    return dmjd
"""
Script Adaptado de stackoverflow Question-31142181. Acesso em 22 mar 2021.
Disponível em: https://stackoverflow.com/questions/31142181/calculating-julian-date-in-python
"""
