# -*- coding: utf-8 -*-
import os
from math import cos,sin,floor,ceil,exp,radians,copysign

def gpt2(lat,lon,alt,dmjd):
    arq = open(os.getcwd()+"/Icos"+"/gpt2_1w.grd.txt",'r')
    dlat = radians(lat); dlon = radians(lon) # Latitude e Longitude em Graus; para Radianos
    hell = alt; pi = 3.14159265359e0; IF1 = 0; EL2 = 0; nl = 0
    dmjd1 = dmjd-51544.5      # Epoca de referência 1 Janeiro de 2000
    dMtr = 28.965e-3          # Massa Molar de Ar Seco em kg/mol
    gm = 9.80665e0            # Gravidade Média em m/s**2
    Rg = 8.3143e0             # Constante Universal dos Gases em J/K/mol
    it = 1  # case 1: Sem Variações de Tempo Estático - case 0: Com Variações (Anuais e Semestrais)
    if (it==1): # Fatores para Amplitudes de Parâmetros Constantes
        cosfy = 0; coshy = 0; sinfy = 0; sinhy = 0
    else:
        cosfy = cos(dmjd1/365.25*2*pi); coshy = cos(dmjd1/365.25*4*pi)
        sinfy = sin(dmjd1/365.25*2*pi); sinhy = sin(dmjd1/365.25*4*pi)
    ###############################################################################
    if ((dlon) < 0):                # Apenas Longitude Positiva em Graus
        plon = ((dlon) + 2*pi)*180/pi
    else:
        plon = (dlon)*180/pi
    ppod = (-dlat + pi/2)*180/pi                        # Transformar para Distância Polar em Graus
    ipod = floor((ppod))+1 ; ilon = floor((plon+1))+1   # Informa a linha mais próximo da grade
    diffpod = (lat - (ipod - 0.5)); difflon = (lon - (ilon - 0.5)) # Diferenças normalizadas positivas ou negativas
    if (ipod == 181): # Adicionado por HCY Alterado para a grade de 1 grau (GP)
        ipod = 180
    if (ilon == 361): # Adicionado pelo GP
        ilon = 1
    if (ilon == 0):
        ilon = 360
    indx = (ipod - 1)*360 + ilon # Obtém o número da linha correspondente ao índice de grade de 1 grau (GAP)
    bilinear = 0                 # Perto dos pólos: interpolação do vizinho mais próximo, caso contrário: bilinear
    if (0.5 < ppod < 179.5):
           bilinear = 1 # print("lat",round(lat,2),"lon",round(lon,2),"Index",indx,"Bilinear",bilinear)
    ################################################################################
    for i in arq:
        ii = i.split(); nl +=1
        if (nl == indx):
            if (bilinear == 1):
                P0 = float(ii[2]) + float(ii[3])*cosfy + float(ii[4])*sinfy + float(ii[5])*coshy + float(ii[6])*sinhy
                T0 = float(ii[7]) + float(ii[8])*cosfy + float(ii[9])*sinfy + float(ii[10])*coshy + float(ii[11])*sinhy
                Q0 = (float(ii[12])+float(ii[13])*cosfy+float(ii[14])*sinfy+float(ii[15])*coshy+float(ii[16])*sinhy)/1000
                DT = (float(ii[17])+float(ii[18])*cosfy+float(ii[19])*sinfy+float(ii[20])*coshy+float(ii[21])*sinhy)/1000
                # Transformando a Altura Elipsoidal em Ortométrica
                undu = float(ii[22])      # Ondulação do Geóide em (m)
                hgt = hell-undu
                Hs = float(ii[23])        # Altitude Ortométrica da Grade em (m)
                redh = hgt - Hs           # Altura da (Estação - grade)
                T = T0 + DT*redh - 273.15 # Temperatura na altura da estação em Celsius
                dT = DT*1000e0            # Taxa de lapso de temperatura em graus / km
                Tv = T0*(1+0.6077*Q0)     # Temperatura virtual em Kelvin
                c = gm*dMtr/(Rg*Tv)
                p = (P0*exp(-c*redh))/100 # Pressão em hPa
                # Coeficiente Hidrostático (ah)
                ah =(float(ii[24])+float(ii[25])*cosfy+float(ii[26])*sinfy+float(ii[27])*coshy+float(ii[28])*sinhy)/1000
                # Coeficiente Úmido (aw)
                aw =(float(ii[29])+float(ii[30])*cosfy+float(ii[31])*sinfy+float(ii[32])*coshy+float(ii[33])*sinhy)/1000
                # Fator de redução de vapor de água la - adicionado pelo GP
                la = float(ii[34]) + float(ii[35])*cosfy + float(ii[36])*sinfy + float(ii[37])*coshy + float(ii[38])*sinhy
                # Temperatura média do vapor de água Tm - adicionado pelo GP
                Tm = float(ii[39]) + float(ii[40])*cosfy + float(ii[41])*sinfy + float(ii[42])*coshy + float(ii[43])*sinhy
                # Pressão de vapor de água em hPa - alterada pelo GP
                e0 = Q0*P0/(0.622+0.378*Q0)/100 # Na Grade
                ef = e0*(100*p/P0)**(la+1) # Na altura da estação - (14) Askne e Nordius, 1987
                IF1 = 1

            else: # Interpolação bilinear
                ipod1 = ipod + copysign(diffpod);
                ilon1 = ilon + copysign(difflon);
                if (ilon1 == 361): # Alterado para a grade de 1 grau (GP)
                    ilon1 = 1
                if (ilon1 == 0):
                    ilon1 = 360
                indx2 = (ipod1 - 1)*360 + ilon  # Ao longo da mesma longitude
                indx3 = (ipod  - 1)*360 + ilon1 # Ao longo da mesma distância polar
                indx4 = (ipod1 - 1)*360 + ilon1 # Diagonal
                for j in range(1,5):
                    if (nl == indx[j]):
                        # Transformando altura elipsoidal em altura ortométrica: Hortho = -N + Inferno
                        P0 = float(ii[2]) + float(ii[3])*cosfy + float(ii[4])*sinfy + float(ii[5])*coshy + float(ii[6])*sinhy
                        T0 = float(ii[7]) + float(ii[8])*cosfy + float(ii[9])*sinfy + float(ii[10])*coshy + float(ii[11])*sinhy
                        Q0j =(float(ii[12])+float(ii[13])*cosfy+float(ii[14])*sinfy+float(ii[15])*coshy+float(ii[16])*sinhy)/1000
                        DTj =(float(ii[17])+float(ii[18])*cosfy+float(ii[19])*sinfy+float(ii[20])*coshy+float(ii[21])*sinhy)/1000
                        unduj = float(ii[22]) # Ondulação do Geóide em (m)
                        Hsj = float(ii[23])   # Altitude Ortométrica em (m)
                        hgt = hell-unduj      # Transformando a Altura Elipsoidal em Ortométrica
                        redh = hgt - Hsj      # Altura da (Estação - grade)
                        Tj = T0 + DTj*redh - 273.15 # Temperatura na altura da estação em Celsius
                        dTj = DTj*1000e0            # Taxa de lapso de temperatura em graus / km
                        Tv = T0*(1+0.6077*Q0j)      # Temperatura virtual em Kelvin
                        c = gm*dMtr/(Rg*Tv)
                        pj = (P0*exp(-c*redh))/100  # Pressão em hPa
                        # Coeficiente Hidrostático (ah)
                        ahj =(float(ii[24])+float(ii[25])*cosfy+float(ii[26])*sinfy+float(ii[27])*coshy+float(ii[28])*sinhy)/1000
                        # Coeficiente Úmido (aw)
                        awj =(float(ii[29])+float(ii[30])*cosfy+float(ii[31])*sinfy+float(ii[32])*coshy+float(ii[33])*sinhy)/1000
                        # Fator de redução de vapor de água la - adicionado pelo GP
                        laj = float(ii[34]) + float(ii[35])*cosfy + float(ii[36])*sinfy + float(ii[37])*coshy + float(ii[38])*sinhy
                        # Temperatura média do vapor de água Tm - adicionado pelo GP
                        Tmj = float(ii[39]) + float(ii[40])*cosfy + float(ii[41])*sinfy + float(ii[42])*coshy + float(ii[43])*sinhy
                        # Pressão de vapor de água em hPa - alterada pelo GP
                        e0 = Q0j*P0/(0.622+0.378*Q0j)/100 # Na Grade
                        ej = e0*(100*pj/P0)**(laj+1); # Na altura da estação - (14) Askne e Nordius, 1987
                dnpod1 = abs(diffpod) # Distância mais perto do ponto
                dnpod2 = 1 - dnpod1   # Distância ao ponto distante
                dnlon1 = abs(difflon); dnlon2 = 1 - dnlon1

                # Pressão
                R1 = dnpod2*pj(1)+dnpod1*pj(2); R2 = dnpod2*pj(3)+dnpod1*pj(4);
                pjf = dnlon2*R1+dnlon1*R2;
                # Temperatura
                R1 = dnpod2*Tj(1)+dnpod1*Tj(2); R2 = dnpod2*Tj(3)+dnpod1*Tj(4);
                Tjf = dnlon2*R1+dnlon1*R2;
                # Temperature em Graus por km
                R1 = dnpod2*dTj(1)+dnpod1*dTj(2); R2 = dnpod2*dTj(3)+dnpod1*dTj(4);
                dTjf = (dnlon2*R1+dnlon1*R2)*1000;
                # Pressão de vapor de água em hPa - alterada pelo GP
                R1 = dnpod2*ej(1)+dnpod1*ej(2); R2 = dnpod2*ej(3)+dnpod1*ej(4);
                ejf = dnlon2*R1+dnlon1*R2;
                # Coeficiente Hidrostático
                R1 = dnpod2*ahj(1)+dnpod1*ahj(2); R2 = dnpod2*ahj(3)+dnpod1*ahj(4);
                ahjf = dnlon2*R1+dnlon1*R2;
                # Coeficiente Úmido
                R1 = dnpod2*awj(1)+dnpod1*awj(2); R2 = dnpod2*awj(3)+dnpod1*awj(4);
                awjf = dnlon2*R1+dnlon1*R2;
                # Ondulação
                R1 = dnpod2*unduj(1)+dnpod1*unduj(2); R2 = dnpod2*unduj(3)+dnpod1*unduj(4);
                undujf = dnlon2*R1+dnlon1*R2;
                # Fator de redução de vapor de água la - adicionado pelo GP
                R1 = dnpod2*laj(1)+dnpod1*laj(2); R2 = dnpod2*laj(3)+dnpod1*laj(4);
                lajf = dnlon2*R1+dnlon1*R2;
                # Temperatura média do vapor de água Tm - adicionado pelo GP
                R1 = dnpod2*Tmj(1)+dnpod1*Tmj(2); R2 = dnpod2*Tmj(3)+dnpod1*Tmj(4);
                Tmjf = dnlon2*R1+dnlon1*R2;
                EL2 = 1
    if (IF1 == 1):
        sif = (ef,p,T,ah,aw,undu,dlat,dlon,la,dT)
        return sif
    if (EL2 == 1):
        sel = (ejf,pjf,Tjf,ahjf,awjf,undujf,dlat,dlon,lajf,dTj)
        return sel
